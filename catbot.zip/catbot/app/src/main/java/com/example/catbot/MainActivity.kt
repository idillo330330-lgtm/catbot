package com.example.catbot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        status = TextView(this).apply { textSize = 18f }
        l.addView(status)
        fun btn(t: String, f: () -> Unit) =
            l.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        btn("1. Activer le service d'accessibilité") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("2. Démarrer le bot") {
            @Suppress("DEPRECATION")
            startActivityForResult(
                getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
        }
        btn("Arrêter") {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.STOP))
        }
        setContentView(l)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (BotAccessibilityService.instance != null)
            "Accessibilité : activée ✓" else "Accessibilité : désactivée ✗"
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data))
        }
    }
}
