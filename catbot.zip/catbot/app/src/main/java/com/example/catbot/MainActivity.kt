package com.example.catbot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    private fun speedFor(progress: Int) = 500 + progress * 500          // 500 ... 6000 px/s (6000 = illimitée)
    private fun label(speed: Int) =
        if (speed >= 6000) "Vitesse de la barre : illimitée" else "Vitesse max de la barre : $speed px/s"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("catbot", MODE_PRIVATE)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        status = TextView(this).apply { textSize = 18f }
        l.addView(status)
        fun btn(t: String, f: () -> Unit) =
            l.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        btn("1. Activer le service d'accessibilité") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("2. Démarrer le bot") {
            @Suppress("DEPRECATION")
            startActivityForResult(
                getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
        }
        btn("Arrêter") {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.STOP))
        }

        // Réglage de la vitesse de la barre (à faire AVANT de démarrer la partie)
        val speedText = TextView(this).apply { textSize = 16f; setPadding(0, 48, 0, 0) }
        val saved = prefs.getInt("speed", 2500)
        speedText.text = label(saved)
        val bar = SeekBar(this).apply {
            max = 11
            progress = ((saved - 500) / 500).coerceIn(0, 11)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = speedFor(p)
                    speedText.text = label(v)
                    prefs.edit().putInt("speed", v).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        l.addView(speedText)
        l.addView(bar)
        l.addView(TextView(this).apply {
            text = "Plus petit = barre plus lente. Le réglage est pris en compte au début de chaque partie."
            textSize = 13f
        })
        setContentView(l)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (BotAccessibilityService.instance != null)
            "Accessibilité : activée ✓" else "Accessibilité : désactivée ✗"
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data))
        }
    }
}
