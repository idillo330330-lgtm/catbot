package com.example.catbot

import java.nio.ByteBuffer

/**
 * Analyse une image du jeu : trouve la barre noire en bas et le chat,
 * puis calcule OÙ la barre doit aller (en tenant compte des rebonds sur les murs).
 * Toutes les coordonnées sont celles de l'image capturée (réduite de moitié).
 */
class Detector(private val w: Int, private val h: Int) {

    class Result(val paddleX: Float, val paddleY: Float, val desiredX: Float)
    private class Pt(val t: Long, val x: Float, val y: Float)

    private val step = 2
    private val history = ArrayDeque<Pt>()
    private var desired = -1f

    // Réglages mesurés sur ta vidéo (fractions de l'écran) — à ajuster si besoin
    private val wallLo = 0.06f * w      // le chat rebondit à gauche ici
    private val wallHi = 0.96f * w      // ... et à droite ici
    private val contactY = 0.875f * h   // hauteur du chat quand il touche la barre

    fun process(buf: ByteBuffer, rs: Int, ps: Int, t: Long): Result? {
        // 1) La barre noire (zone 88%-97% de la hauteur)
        var minX = Int.MAX_VALUE
        var maxX = -1
        var sumY = 0L
        var n = 0
        var y = (h * 0.88f).toInt()
        val yEnd = (h * 0.97f).toInt()
        while (y < yEnd) {
            var x = 0
            while (x < w) {
                val o = y * rs + x * ps
                val r = buf.get(o).toInt() and 0xFF
                val g = buf.get(o + 1).toInt() and 0xFF
                val b = buf.get(o + 2).toInt() and 0xFF
                if (r < 40 && g < 40 && b < 40) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    sumY += y
                    n++
                }
                x += step
            }
            y += step
        }
        if (n < 50) return null
        val widthFrac = (maxX - minX).toFloat() / w
        if (widthFrac < 0.15f || widthFrac > 0.32f) return null   // la barre fait ~24% de la largeur
        val paddleX = (minX + maxX) / 2f
        val paddleY = sumY.toFloat() / n

        // 2) Le chat : pixels orange (le fond est jaune pâle, le score gris-olive)
        var sx = 0L
        var sy = 0L
        var c = 0
        y = (h * 0.08f).toInt()       // on ignore l'en-tête (avatars, couronne)
        val yMax = (h * 0.98f).toInt()
        while (y < yMax) {
            var x = 0
            while (x < w) {
                val o = y * rs + x * ps
                val r = buf.get(o).toInt() and 0xFF
                val g = buf.get(o + 1).toInt() and 0xFF
                val b = buf.get(o + 2).toInt() and 0xFF
                if (r > 200 && g in 130..215 && b < 100) {
                    sx += x
                    sy += y
                    c++
                }
                x += step
            }
            y += step
        }

        if (c >= 30) {
            val cx = sx.toFloat() / c
            val cy = sy.toFloat() / c
            history.addLast(Pt(t, cx, cy))
            while (history.size > 1 && t - history.first().t > 250_000_000L) history.removeFirst()
            desired = predict(cx, cy)
        } else if (history.isNotEmpty() && t - history.last().t > 600_000_000L) {
            history.clear()
        }
        if (desired < 0f) desired = paddleX
        return Result(paddleX, paddleY, desired.coerceIn(0.12f * w, 0.88f * w))
    }

    /** Où le chat va arriver en bas, avec rebonds sur les murs gauche/droite. */
    private fun predict(cx: Float, cy: Float): Float {
        val first = history.first()
        val last = history.last()
        val dt = (last.t - first.t) / 1e9f
        if (dt < 0.06f) return cx
        val vx = (last.x - first.x) / dt
        val vy = (last.y - first.y) / dt
        if (vy < 40f || cy >= contactY) return cx          // le chat monte : on le suit
        val tt = (contactY - cy) / vy
        val span = wallHi - wallLo
        var u = (cx + vx * tt - wallLo) % (2 * span)
        if (u < 0) u += 2 * span
        if (u > span) u = 2 * span - u                      // rebond
        return wallLo + u
    }
}
