package com.example.catbot

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * Analyse une image du jeu : trouve la barre noire en bas et le chat,
 * puis calcule OÙ la barre doit aller (rebonds sur les murs ET en haut compris).
 * Toutes les coordonnées sont celles de l'image capturée (réduite de moitié).
 */
class Detector(private val w: Int, private val h: Int) {

    class Result(val paddleX: Float, val paddleY: Float, val desiredX: Float)
    private class Pt(val t: Long, val x: Float, val y: Float)

    // valeurs de debug écrites dans le journal
    var dbgCx = Float.NaN
    var dbgCy = Float.NaN
    var dbgVx = 0f
    var dbgVy = 0f
    var sx = 1.1f * w
        private set
    var sy = 0.47f * h
        private set

    private val history = ArrayDeque<Pt>()
    private var desired = -1f
    private var stillSince = 0L
    private var frame = 0L
    private var paddleOk = false
    private var paddleX = 0f
    private var paddleY = 0f
    private val hx = IntArray(600)
    private val hy = IntArray(600)

    // Réglages mesurés sur ton journal (en pixels de l'image réduite)
    private val wallLo = 0.06f * w      // le chat rebondit à gauche ici
    private val wallHi = 0.96f * w      // ... et à droite ici
    private val topY = 0.02f * h        // ... et en haut (derrière la barre d'état)
    private val contactY = 0.875f * h   // hauteur du chat quand il touche la barre

    fun process(buf: ByteBuffer, rs: Int, ps: Int, t: Long): Result? {
        buf.order(ByteOrder.LITTLE_ENDIAN)
        val ib = buf.asIntBuffer()
        val stride = rs / 4

        // 1) La barre noire (zone 88%-97% de la hauteur). Elle bouge peu : on ne la cherche qu'une image sur 6.
        frame++
        if (frame % 6L == 1L || !paddleOk) {
            var minX = Int.MAX_VALUE
            var maxX = -1
            var sumY = 0L
            var n = 0
            var yy = (h * 0.88f).toInt()
            val yEnd = (h * 0.97f).toInt()
            while (yy < yEnd) {
                val row = yy * stride
                var x = 0
                while (x < w) {
                    val v = ib.get(row + x)
                    if ((v and 0xFF) < 40 && ((v ushr 8) and 0xFF) < 40 && ((v ushr 16) and 0xFF) < 40) {
                        if (x < minX) minX = x
                        if (x > maxX) maxX = x
                        sumY += yy
                        n++
                    }
                    x += 3
                }
                yy += 3
            }
            paddleOk = n >= 60 && (maxX - minX).toFloat() / w in 0.15f..0.32f   // la barre fait ~24% de la largeur
            if (paddleOk) {
                paddleX = (minX + maxX) / 2f
                paddleY = sumY.toFloat() / n
            }
        }
        if (!paddleOk) return null

        // 2) Le chat. La couleur du fond change selon le niveau (jaune, orange...), donc on ne cherche pas
        //    « du orange » : on mesure la couleur du fond, puis on garde les pixels qui n'ont pas la même
        //    teinte que lui. Le gros chiffre du score est le fond en plus foncé (même teinte) : il est ignoré.
        var bgR = 0f
        var bgG = 0f
        var bgB = 0f
        run {
            val px = floatArrayOf(0.1f, 0.5f, 0.9f, 0.1f, 0.9f, 0.1f, 0.5f, 0.9f)
            val py = floatArrayOf(0.2f, 0.2f, 0.2f, 0.6f, 0.6f, 0.8f, 0.8f, 0.8f)
            val rs8 = IntArray(8)
            val gs8 = IntArray(8)
            val bs8 = IntArray(8)
            for (i in 0 until 8) {
                val v = ib.get((py[i] * h).toInt() * stride + (px[i] * w).toInt())
                rs8[i] = v and 0xFF
                gs8[i] = (v ushr 8) and 0xFF
                bs8[i] = (v ushr 16) and 0xFF
            }
            rs8.sort(); gs8.sort(); bs8.sort()
            bgR = (rs8[3] + rs8[4]) / 2f
            bgG = (gs8[3] + gs8[4]) / 2f
            bgB = (bs8[3] + bs8[4]) / 2f
        }
        val bgSum = bgR + bgG + bgB
        val yTop = (h * 0.09f).toInt()     // on ignore l'en-tête (avatars, couronne)
        val yMax = (h * 0.90f).toInt()     // et la zone de la barre

        // 2a) balayage grossier (1 point sur 12) pour savoir où est le chat
        var nh = 0
        var y = yTop
        while (y < yMax) {
            val row = y * stride
            var x = 6
            while (x < w - 6) {
                if (nh < hx.size && isCat(ib.get(row + x), bgR, bgG, bgB, bgSum)) {
                    hx[nh] = x
                    hy[nh] = y
                    nh++
                }
                x += 12
            }
            y += 12
        }

        // 2b) balayage fin autour de ce point pour avoir sa position exacte
        var sumCx = 0L
        var sumCy = 0L
        var c = 0
        if (nh >= 3) {
            val xs = hx.copyOf(nh)
            val ys = hy.copyOf(nh)
            xs.sort()
            ys.sort()
            val mx = xs[nh / 2]
            val my = ys[nh / 2]
            val x0 = maxOf(6, mx - 48)
            val x1 = minOf(w - 6, mx + 48)
            val y0 = maxOf(yTop, my - 48)
            val y1 = minOf(yMax, my + 48)
            var yy = y0
            while (yy < y1) {
                val row = yy * stride
                var x = x0
                while (x < x1) {
                    if (isCat(ib.get(row + x), bgR, bgG, bgB, bgSum)) {
                        sumCx += x
                        sumCy += yy
                        c++
                    }
                    x += 3
                }
                yy += 3
            }
        }

        if (c >= 20) {
            val cx = sumCx.toFloat() / c
            val cy = sumCy.toFloat() / c
            dbgCx = cx
            dbgCy = cy
            val prev = history.lastOrNull()
            if (prev != null && abs(cx - prev.x) + abs(cy - prev.y) < 6f) {
                if (stillSince == 0L) stillSince = prev.t
            } else {
                stillSince = 0L
            }
            history.addLast(Pt(t, cx, cy))
            while (history.size > 1 && t - history.first().t > 500_000_000L) history.removeFirst()
            desired = predict()
            // le « chat » ne bouge plus depuis 0,8 s : écran de fin de partie -> on lève le doigt
            if (stillSince != 0L && t - stillSince > 800_000_000L) { desired = -1f; return null }
        } else {
            dbgCx = Float.NaN
            dbgCy = Float.NaN
            if (history.isNotEmpty() && t - history.last().t > 700_000_000L) history.clear()
        }
        if (desired < 0f) desired = paddleX
        return Result(paddleX, paddleY, desired.coerceIn(0.12f * w, 0.88f * w))
    }

    /** Vrai si le pixel n'a pas la teinte du fond (ni noir) : c'est le chat. */
    private fun isCat(v: Int, bgR: Float, bgG: Float, bgB: Float, bgSum: Float): Boolean {
        val r = v and 0xFF
        val g = (v ushr 8) and 0xFF
        val b = (v ushr 16) and 0xFF
        val k = (r + g + b) / bgSum
        if (k <= 0.35f) return false
        return abs(r - k * bgR) + abs(g - k * bgG) + abs(b - k * bgB) > 40f
    }

    /** Où le chat va arriver en bas. Gère les rebonds : la direction est déduite par « dépliage » du trajet. */
    private fun predict(): Float {
        val p1 = history.last()
        var p0: Pt? = null
        for (i in history.size - 2 downTo 0) {
            if (p1.t - history[i].t >= 50_000_000L) { p0 = history[i]; break }
        }
        if (p0 == null) return if (desired >= 0f) desired else p1.x
        val dt = (p1.t - p0.t) / 1e9f

        // chat immobile (écran de fin, pause...) : on garde la cible, sinon la barre part dans tous les sens
        val moved = abs(p1.x - p0.x) + abs(p1.y - p0.y)
        if (moved < 12f) return if (desired >= 0f) desired else p1.x

        // vitesses : mesurées seulement sur des trajets courts loin des murs (pas de rebond entre les 2 points)
        val clean = dt < 0.2f
        val mx = 0.15f * w
        val my = 0.06f * h
        if (clean && p0.x in (wallLo + mx)..(wallHi - mx) && p1.x in (wallLo + mx)..(wallHi - mx)) {
            val s = abs(p1.x - p0.x) / dt
            if (s in 0.3f * w..5.0f * w) sx = 0.5f * sx + 0.5f * s
        }
        if (clean && p0.y in (topY + my)..(contactY - my) && p1.y in (topY + my)..(contactY - my)) {
            val s = abs(p1.y - p0.y) / dt
            if (s in 0.15f * h..2.5f * h) sy = 0.5f * sy + 0.5f * s
        }

        // directions : celle qui, avec les rebonds, explique le mieux où le chat est passé
        val dirX = currentDir(p0.x, p1.x, sx * dt, wallLo, wallHi)
        val dirY = currentDir(p0.y, p1.y, sy * dt, topY, contactY)
        dbgVx = dirX * sx
        dbgVy = dirY * sy

        if (p1.y >= contactY) return p1.x
        val tt = if (dirY > 0) (contactY - p1.y) / sy
                 else ((p1.y - topY) + (contactY - topY)) / sy     // monte, rebondit en haut, puis descend
        return fold(p1.x + dirX * sx * tt, wallLo, wallHi)
    }

    /**
     * Sens ACTUEL du chat au point b (après les rebonds éventuels entre a et b).
     * On « déplie » le trajet : le sens de départ est celui qui explique le mieux b ;
     * chaque rebond rencontré en route inverse ensuite le sens.
     */
    private fun currentDir(a: Float, b: Float, dist: Float, lo: Float, hi: Float): Int {
        val span = hi - lo
        val plus = abs(fold(a + dist, lo, hi) - b)
        val minus = abs(fold(a - dist, lo, hi) - b)
        val start = if (plus <= minus) 1 else -1
        val z = (a - lo) + start * dist
        val k = Math.floor((z / span).toDouble()).toInt()
        return if (k % 2 == 0) start else -start
    }

    /** Replie une position dans [lo, hi] en tenant compte des rebonds. */
    private fun fold(p: Float, lo: Float, hi: Float): Float {
        val span = hi - lo
        var u = (p - lo) % (2 * span)
        if (u < 0) u += 2 * span
        if (u > span) u = 2 * span - u
        return lo + u
    }
}
