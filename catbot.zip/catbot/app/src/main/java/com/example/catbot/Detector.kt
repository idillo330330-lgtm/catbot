package com.example.catbot

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * Analyse une image du jeu : trouve la barre noire en bas et le chat,
 * puis calcule OÙ la barre doit aller (rebonds sur les murs ET en haut compris).
 * Toutes les coordonnées sont celles de l'image capturée (réduite de moitié).
 */
class Detector(private val w: Int, private val h: Int) {

    class Result(val paddleX: Float, val paddleY: Float, val desiredX: Float)
    private class Pt(val t: Long, val x: Float, val y: Float)

    // valeurs de debug écrites dans le journal
    var dbgCx = Float.NaN
    var dbgCy = Float.NaN
    var dbgVx = 0f
    var dbgVy = 0f
    var sx = 1.1f * w
        private set
    var sy = 0.47f * h
        private set

    private val history = ArrayDeque<Pt>()
    private var desired = -1f

    // Réglages mesurés sur ton journal (en pixels de l'image réduite)
    private val wallLo = 0.06f * w      // le chat rebondit à gauche ici
    private val wallHi = 0.96f * w      // ... et à droite ici
    private val topY = 0.02f * h        // ... et en haut (derrière la barre d'état)
    private val contactY = 0.875f * h   // hauteur du chat quand il touche la barre

    fun process(buf: ByteBuffer, rs: Int, ps: Int, t: Long): Result? {
        buf.order(ByteOrder.LITTLE_ENDIAN)
        val ib = buf.asIntBuffer()
        val stride = rs / 4

        // 1) La barre noire (zone 88%-97% de la hauteur)
        var minX = Int.MAX_VALUE
        var maxX = -1
        var sumY = 0L
        var n = 0
        var y = (h * 0.88f).toInt()
        val yEnd = (h * 0.97f).toInt()
        while (y < yEnd) {
            val row = y * stride
            var x = 0
            while (x < w) {
                val v = ib.get(row + x)
                if ((v and 0xFF) < 40 && ((v ushr 8) and 0xFF) < 40 && ((v ushr 16) and 0xFF) < 40) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    sumY += y
                    n++
                }
                x += 2
            }
            y += 2
        }
        if (n < 100) return null
        val widthFrac = (maxX - minX).toFloat() / w
        if (widthFrac < 0.15f || widthFrac > 0.32f) return null   // la barre fait ~24% de la largeur
        val paddleX = (minX + maxX) / 2f
        val paddleY = sumY.toFloat() / n

        // 2) Le chat : pixels orange (le fond est jaune pâle, le score gris-olive)
        var sumCx = 0L
        var sumCy = 0L
        var c = 0
        y = (h * 0.08f).toInt()       // on ignore l'en-tête (avatars, couronne)
        val yMax = (h * 0.98f).toInt()
        while (y < yMax) {
            val row = y * stride
            var x = 0
            while (x < w) {
                val v = ib.get(row + x)
                val r = v and 0xFF
                val g = (v ushr 8) and 0xFF
                val b = (v ushr 16) and 0xFF
                if (r > 200 && g in 130..215 && b < 100) {
                    sumCx += x
                    sumCy += y
                    c++
                }
                x += 4
            }
            y += 4
        }

        if (c >= 12) {
            val cx = sumCx.toFloat() / c
            val cy = sumCy.toFloat() / c
            dbgCx = cx
            dbgCy = cy
            history.addLast(Pt(t, cx, cy))
            while (history.size > 1 && t - history.first().t > 500_000_000L) history.removeFirst()
            desired = predict()
        } else {
            dbgCx = Float.NaN
            dbgCy = Float.NaN
            if (history.isNotEmpty() && t - history.last().t > 700_000_000L) history.clear()
        }
        if (desired < 0f) desired = paddleX
        return Result(paddleX, paddleY, desired.coerceIn(0.12f * w, 0.88f * w))
    }

    /** Où le chat va arriver en bas. Gère les rebonds : la direction est déduite par « dépliage » du trajet. */
    private fun predict(): Float {
        val p1 = history.last()
        var p0: Pt? = null
        for (i in history.size - 2 downTo 0) {
            if (p1.t - history[i].t >= 50_000_000L) { p0 = history[i]; break }
        }
        if (p0 == null) return if (desired >= 0f) desired else p1.x
        val dt = (p1.t - p0.t) / 1e9f

        // chat immobile (écran de fin, pause...) : on garde la cible, sinon la barre part dans tous les sens
        val moved = abs(p1.x - p0.x) + abs(p1.y - p0.y)
        if (moved < 12f) return if (desired >= 0f) desired else p1.x

        // vitesses : mesurées seulement sur des trajets courts loin des murs (pas de rebond entre les 2 points)
        val clean = dt < 0.2f
        val mx = 0.15f * w
        val my = 0.06f * h
        if (clean && p0.x in (wallLo + mx)..(wallHi - mx) && p1.x in (wallLo + mx)..(wallHi - mx)) {
            val s = abs(p1.x - p0.x) / dt
            if (s in 0.3f * w..5.0f * w) sx = 0.5f * sx + 0.5f * s
        }
        if (clean && p0.y in (topY + my)..(contactY - my) && p1.y in (topY + my)..(contactY - my)) {
            val s = abs(p1.y - p0.y) / dt
            if (s in 0.15f * h..2.5f * h) sy = 0.5f * sy + 0.5f * s
        }

        // directions : celle qui, avec les rebonds, explique le mieux où le chat est passé
        val dirX = currentDir(p0.x, p1.x, sx * dt, wallLo, wallHi)
        val dirY = currentDir(p0.y, p1.y, sy * dt, topY, contactY)
        dbgVx = dirX * sx
        dbgVy = dirY * sy

        if (p1.y >= contactY) return p1.x
        val tt = if (dirY > 0) (contactY - p1.y) / sy
                 else ((p1.y - topY) + (contactY - topY)) / sy     // monte, rebondit en haut, puis descend
        return fold(p1.x + dirX * sx * tt, wallLo, wallHi)
    }

    /**
     * Sens ACTUEL du chat au point b (après les rebonds éventuels entre a et b).
     * On « déplie » le trajet : le sens de départ est celui qui explique le mieux b ;
     * chaque rebond rencontré en route inverse ensuite le sens.
     */
    private fun currentDir(a: Float, b: Float, dist: Float, lo: Float, hi: Float): Int {
        val span = hi - lo
        val plus = abs(fold(a + dist, lo, hi) - b)
        val minus = abs(fold(a - dist, lo, hi) - b)
        val start = if (plus <= minus) 1 else -1
        val z = (a - lo) + start * dist
        val k = Math.floor((z / span).toDouble()).toInt()
        return if (k % 2 == 0) start else -start
    }

    /** Replie une position dans [lo, hi] en tenant compte des rebonds. */
    private fun fold(p: Float, lo: Float, hi: Float): Float {
        val span = hi - lo
        var u = (p - lo) % (2 * span)
        if (u < 0) u += 2 * span
        if (u > span) u = 2 * span - u
        return lo + u
    }
}
