package com.example.catbot

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.WindowManager

/** Capture l'écran en continu (service de premier plan) et envoie la cible au service d'accessibilité. */
class CaptureService : Service() {

    companion object { const val STOP = "stop" }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var lastSeen = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "CatBot", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val notif = Notification.Builder(this, "bot")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("CatBot actif")
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_delete), "Arrêter", stopPi).build())
            .build()
        startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra("code", 0) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY

        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, null)

        val full = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        val scale = 2                                   // on analyse l'écran en demi-résolution
        val cw = full.width() / scale
        val ch = full.height() / scale
        val detector = Detector(cw, ch)

        thread = HandlerThread("capture").also { it.start() }
        val handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val pl = img.planes[0]
                handle(detector.process(pl.buffer, pl.rowStride, pl.pixelStride, System.nanoTime()), scale)
            } finally {
                img.close()
            }
        }, handler)
        vdisplay = projection!!.createVirtualDisplay(
            "catbot", cw, ch, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        return START_NOT_STICKY
    }

    private fun handle(r: Detector.Result?, scale: Int) {
        val svc = BotAccessibilityService.instance ?: return
        val now = System.nanoTime()
        if (r != null) {
            lastSeen = now
            svc.update(r.paddleX * scale, r.paddleY * scale, r.desiredX * scale)
        } else if (now - lastSeen > 300_000_000L) {   // barre absente depuis 0,3 s -> fin de partie
            svc.update(null, 0f, 0f)
        }
    }

    override fun onDestroy() {
        BotAccessibilityService.instance?.update(null, 0f, 0f)
        vdisplay?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
}
