package com.example.catbot

import android.app.*
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.WindowManager

/** Capture l'écran en continu (service de premier plan) et envoie la cible au service d'accessibilité. */
class CaptureService : Service() {

    companion object { const val STOP = "stop" }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var lastSeen = 0L
    private var offSince = 0L
    private var procMs = 0
    private var detector: Detector? = null
    private val log = StringBuilder("t_ms,paddleX,paddleY,catX,catY,desiredX,vx,vy,cmdX,disp,done,sx,sy,proc_ms\n")
    private val t0 = System.nanoTime()

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "CatBot", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val notif = Notification.Builder(this, "bot")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("CatBot actif")
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_delete), "Arrêter", stopPi).build())
            .build()
        startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra("code", 0) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY

        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, null)

        val full = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        val scale = 2                                   // on analyse l'écran en demi-résolution
        val cw = full.width() / scale
        val ch = full.height() / scale
        val detector = Detector(cw, ch)
        this.detector = detector

        thread = HandlerThread("capture").also { it.start() }
        val handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val pl = img.planes[0]
                val t1 = System.nanoTime()
                val res = detector.process(pl.buffer, pl.rowStride, pl.pixelStride, t1)
                procMs = ((System.nanoTime() - t1) / 1_000_000).toInt()
                handle(res, scale)
            } finally {
                img.close()
            }
        }, handler)
        vdisplay = projection!!.createVirtualDisplay(
            "catbot", cw, ch, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
        return START_NOT_STICKY
    }

    private fun handle(r: Detector.Result?, scale: Int) {
        val svc = BotAccessibilityService.instance ?: return
        val now = System.nanoTime()
        if (r != null) {
            lastSeen = now
            svc.update(r.paddleX * scale, r.paddleY * scale, r.desiredX * scale)
            // la barre ne suit plus le doigt depuis 0,8 s (nouvelle partie, doigt perdu...) : on lève le doigt
            if (svc.disp > 0 && svc.cmdX > 0f && Math.abs(r.paddleX * scale - svc.cmdX) > 300f) {
                if (offSince == 0L) offSince = now
                else if (now - offSince > 800_000_000L) { svc.forceRelease(); offSince = 0L }
            } else {
                offSince = 0L
            }
            val d = detector
            if (d != null && log.length < 300_000) {
                log.append((now - t0) / 1_000_000).append(',')
                    .append((r.paddleX * scale).toInt()).append(',')
                    .append((r.paddleY * scale).toInt()).append(',')
                    .append(if (d.dbgCx.isNaN()) "" else (d.dbgCx * scale).toInt().toString()).append(',')
                    .append(if (d.dbgCy.isNaN()) "" else (d.dbgCy * scale).toInt().toString()).append(',')
                    .append((r.desiredX * scale).toInt()).append(',')
                    .append((d.dbgVx * scale).toInt()).append(',')
                    .append((d.dbgVy * scale).toInt()).append(',')
                    .append(svc.cmdX.toInt()).append(',')
                    .append(svc.disp).append(',')
                    .append(svc.done).append(',')
                    .append((d.sx * scale).toInt()).append(',')
                    .append((d.sy * scale).toInt()).append(',')
                    .append(procMs).append('\n')
            }
        } else if (now - lastSeen > 300_000_000L) {   // barre absente depuis 0,3 s -> fin de partie
            svc.update(null, 0f, 0f)
        }
    }

    private fun saveLog() {
        try {
            if (log.length < 200) return
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "catbot-log-${System.currentTimeMillis() / 1000}.csv")
                put(MediaStore.Downloads.MIME_TYPE, "text/csv")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return
            contentResolver.openOutputStream(uri)?.use { it.write(log.toString().toByteArray()) }
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        saveLog()
        BotAccessibilityService.instance?.update(null, 0f, 0f)
        vdisplay?.release()
        reader?.close()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
}
