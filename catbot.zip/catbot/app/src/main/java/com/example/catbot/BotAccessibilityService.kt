package com.example.catbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

/** Pose un doigt « virtuel » sur la barre et le fait glisser en continu vers la cible. */
class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotAccessibilityService? = null
    }
    @Volatile var cmdX = 0f
    @Volatile var disp = 0
    @Volatile var done = 0

    private val main = Handler(Looper.getMainLooper())
    private var stroke: GestureDescription.StrokeDescription? = null
    private var active = false
    private var fingerX = 0f
    private var fingerY = 0f
    private var flip = 1f
    @Volatile private var targetX = 0f
    @Volatile private var wanted = false

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** paddleX == null : plus de jeu à l'écran -> on lève le doigt. Coordonnées en pixels écran. */
    fun update(paddleX: Float?, y: Float, desiredX: Float) {
        if (paddleX == null) { wanted = false; return }
        targetX = desiredX
        wanted = true
        main.post {
            if (!active) {
                active = true
                fingerX = paddleX
                fingerY = y
                stroke = null
                next()
            }
        }
    }

    private fun next() {
        val cont = wanted
        var nx = if (cont) targetX else fingerX
        if (abs(nx - fingerX) < 1f) { flip = -flip; nx = fingerX + flip }   // évite un trait de longueur 0
        val p = Path().apply { moveTo(fingerX, fingerY); lineTo(nx, fingerY) }
        val st = stroke?.continueStroke(p, 0, 40, cont)
            ?: GestureDescription.StrokeDescription(p, 0, 40, cont)
        stroke = st
        cmdX = nx
        disp++
        val ok = dispatchGesture(
            GestureDescription.Builder().addStroke(st).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) {
                    fingerX = nx
                    done++
                    if (cont) next() else { active = false; stroke = null }
                }
                override fun onCancelled(g: GestureDescription?) { active = false; stroke = null }
            }, null
        )
        if (!ok) { active = false; stroke = null }
    }
}
